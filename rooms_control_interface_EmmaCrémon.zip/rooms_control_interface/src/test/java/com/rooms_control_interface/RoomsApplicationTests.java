package com.rooms_control_interface;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomsApplicationTests {

	@Test
	void contextLoads() {
	}

}
