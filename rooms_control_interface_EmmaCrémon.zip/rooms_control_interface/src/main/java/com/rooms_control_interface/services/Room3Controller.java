package com.rooms_control_interface.services;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Room3Controller {
    @GetMapping("/Room3")
    public String Room3Controller(){
        return "Room3";
    }
}
