package com.rooms_control_interface.services;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Room2Controller {
    @GetMapping("/Room2")
    public String Room2Controller(){
        return "Room2";
    }
}
